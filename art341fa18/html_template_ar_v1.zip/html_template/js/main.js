$(function() {
	
	// jQuery code goes here
	
	
	
});